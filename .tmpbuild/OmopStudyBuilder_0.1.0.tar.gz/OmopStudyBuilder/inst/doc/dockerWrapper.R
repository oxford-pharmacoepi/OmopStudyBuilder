## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(OmopStudyBuilder)

## ----dockeriseStudy-example, eval=FALSE---------------------------------------
# # From the studyCode folder (or pass path=...)
# dockeriseStudy(
#   image_name = "my-study",
#   path = "./studyCode",
#   useRStudio = FALSE
# )

## ----dockeriseStudy-rstudio, eval=FALSE---------------------------------------
# dockeriseStudy(
#   image_name = "my-study",
#   path = "./studyCode",
#   useRStudio = TRUE
# )

## ----dockeriseStudy-github-token, eval=FALSE----------------------------------
# dockeriseStudy(
#   path = "./studyCode",
#   github_token = Sys.getenv("GITHUB_PAT")
# )

## ----runRStudio-example, eval=FALSE-------------------------------------------
# runRStudio(
#   image_name = "my-study",
#   results_path = "./results"
# )

## ----runStudy-example, eval=FALSE---------------------------------------------
# runStudy(
#   image_name = "my-study",
#   results_path = "./results",
#   data_path = "/path/to/cdm/data",
#   script_path = "codeToRun.R"
# )

## ----stopStudy-example, eval=FALSE--------------------------------------------
# stopStudy(image_name = "my-study")

## ----pushDockerImage-example, eval=FALSE--------------------------------------
# pushDockerImage(
#   image_name = "my-study",
#   repo = "yourusername/my-study"
# )

