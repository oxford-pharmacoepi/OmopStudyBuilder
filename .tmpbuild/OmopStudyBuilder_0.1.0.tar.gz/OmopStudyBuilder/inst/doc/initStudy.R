## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include=FALSE-----------------------------------------------------
library(OmopStudyBuilder)

## ----basic-usage, message=FALSE-----------------------------------------------
# Create a temporary root for this vignette
study_root <- file.path(tempdir(), "SampleStudy")

initStudy(study_root)

# Show top-level contents created by initStudy()
list.files(study_root)

## ----list-recursive-----------------------------------------------------------
list.files(study_root, recursive = TRUE)

## ----diagnostics-only, message=FALSE------------------------------------------
diag_root <- file.path(tempdir(), "DiagnosticsOnly")

initStudy(
  directory   = diag_root,
  diagnostics = TRUE,
  study       = FALSE
)

list.files(diag_root)

## ----study-only, message=FALSE------------------------------------------------
study_only_root <- file.path(tempdir(), "StudyOnly")

initStudy(
  directory   = study_only_root,
  diagnostics = FALSE,
  study       = TRUE
)

list.files(study_only_root)

## ----build-docker, eval=FALSE-------------------------------------------------
# # Build a Docker image containing your study code
# dockeriseStudy(
#   image_name = "omop-study-study-code",
#   path = file.path(study_root, "studyCode")
# )
# #> Building Docker image: omop-study-study-code
# #> This may take some minutes on first build...
# #> ✔ Image built successfully: omop-study-study-code

## ----push-image, eval=FALSE---------------------------------------------------
# pushDockerImage(
#   image_name = "omop-study-study-code",
#   repo = "yourusername/myomopstudy"
# )
# #> ✔ Image pushed to Docker Hub!

## ----pull-run, eval=FALSE-----------------------------------------------------
# library(OmopStudyBuilder)
# 
# # Interactive (requires image built with dockeriseStudy(useRStudio = TRUE)):
# runRStudio(
#   image_name = "yourusername/myomopstudy:latest",
#   results_path = "./results"
# )

## ----rstudio-run, eval=FALSE--------------------------------------------------
# # Requires image built with dockeriseStudy(useRStudio = TRUE)
# runRStudio(
#   image_name = "omop-study-study-code",
#   results_path = "./results"
# )

## ----auto-run, eval=FALSE-----------------------------------------------------
# runStudy(
#   image_name = "omop-study-study-code",
#   results_path = "./results",
#   data_path = "path/to/data"
# )

## ----stop-containers, eval=FALSE----------------------------------------------
# stopStudy(image_name = "omop-study-study-code")

