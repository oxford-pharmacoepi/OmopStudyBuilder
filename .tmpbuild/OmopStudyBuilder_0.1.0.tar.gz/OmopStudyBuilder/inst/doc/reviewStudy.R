## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(OmopStudyBuilder)

## ----reviewStudyCode-example, eval=FALSE--------------------------------------
# reviewStudyCode(".")

## ----reviewStudyDependencies-example, eval=FALSE------------------------------
# reviewStudyDependencies(
#   dir = ".",
#   type = "analysis"
# )

